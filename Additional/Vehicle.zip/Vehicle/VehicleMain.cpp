#include <iostream>
#include "Bus.h"
#include "Horse.h"

int main()
{
	Buss Hi;
	Hi.Feed(1);
	Horse ho;
	ho.Feed(1);
	ho.Sleep(1);
}

