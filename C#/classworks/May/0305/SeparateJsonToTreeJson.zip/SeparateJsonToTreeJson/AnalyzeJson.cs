﻿using SeparateJsonToTreeJson.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeparateJsonToTreeJson
{
    public static class AnalyzeJson
    {
        public static void ConectFeaturesToOptions(Dictionary<string, FeatureRequest> features, FeatureRequest code)
        {
            //if (code.options)
            //{
                
            //}
        }
    }
}
