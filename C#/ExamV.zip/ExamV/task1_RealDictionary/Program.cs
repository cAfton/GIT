﻿using task1_RealDictionary.Models;

namespace task1_RealDictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            task_manager.Menu();
        }
    }
}
