﻿using Task1_Dictionary.Models;

namespace Task1_Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Task_Manager.RunTask();
        }
    }
}
